import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class ManageTest {

    public ManageTest() {
    }

    // This method will run once before all tests
    @BeforeAll
    public static void setUpClass() {
        System.out.println("Setting up before all tests");
    }

    // This method will run once after all tests
    @AfterAll
    public static void tearDownClass() {
        System.out.println("Tearing down after all tests");
    }

    // This method will run before each test
    @BeforeEach
    public void setUp() {
        System.out.println("Setting up before each test");
    }

    // This method will run after each test
    @AfterEach
    public void tearDown() {
        System.out.println("Tearing down after each test");
    }

    // Test case example 1
    @Test
    public void testMessageSizeSuccess() {
        String message = "Hi Mike, can you join us for dinner tonight?";
        assertTrue(message.length() <= 250, "Message is too long");
    }

    // Test case example 2 (failure case)
    @Test
    public void testMessageSizeFailure() {
        String message = "Hi Mike, can you join us for dinner tonight? " + 
                         "It's going to be a fun night, with lots of food and drinks and..." +
                         " everything you could imagine. It's going to be a super long message!";
        assertTrue(message.length() <= 250, "Message exceeds 250 characters");
    }

    // Test case example for recipient number validation (success case)
    @Test
    public void testValidRecipientNumber() {
        String recipientNumber = "+27718693002";
        assertTrue(recipientNumber.matches("\\+\\d{11}"), "Cell phone number is incorrectly formatted");
    }

    // Test case example for recipient number validation (failure case)
    @Test
    public void testInvalidRecipientNumber() {
        String recipientNumber = "0181234567";
        assertFalse(recipientNumber.matches("\\+\\d{11}"), "Cell phone number is incorrectly formatted or missing international code");
    }

    // Test case example for message hash generation
    @Test
    public void testGenerateMessageHash() {
        String messageId = "0012345678";
        String message = "Hi Mike, can you join us for dinner tonight?";
        String expectedHash = "00:0:HITHANKS";

        String generatedHash = generateMessageHash(messageId, message);
        assertEquals(expectedHash, generatedHash, "Message hash is incorrect");
    }

    // This method simulates message hash generation (based on your requirement)
    private String generateMessageHash(String messageId, String message) {
        String firstTwoDigits = messageId.substring(0, 2);
        String firstWord = message.split(" ")[0].toUpperCase();
        String lastWord = message.split(" ")[message.split(" ").length - 1].toUpperCase();

        return firstTwoDigits + ":0:" + firstWord + lastWord;
    }
}
