/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

import java.util.regex.*;
import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class Login {
    String registeredUsername;
    String registeredPassword;
    private String registeredCell;

    // Check if username contains an underscore and is no more than 5 characters long
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Check if password meets all required conditions
    public boolean checkPasswordComplexity(String password) {
        boolean length = password.length() >= 8;
        boolean capital = password.matches(".*[A-Z].*");
        boolean number = password.matches(".*\\d.*");
        boolean special = password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");

        return length && capital && number && special;
    }

    // Cellphone number must start with +27 and be 13 digits total (e.g. +27821234567)
    // Reference: OpenAI. (2025). *ChatGPT (Apr 12 version)* [Large language model]. Available at: https://chat.openai.com/chat
    public boolean checkCellPhoneNumber(String cellphone) {
        String pattern = "\\+27\\d{9}";
        return cellphone.matches(pattern);
    }

    // Handles user registration with input validation in a loop
    public String registerUser() {
        String username = "";
        String password = "";
        String cellphone = "";

        // Loop until valid username, password, and cellphone are entered
        while (true) {
            username = JOptionPane.showInputDialog("Enter a username (must contain an underscore and be no more than 5 characters long):");
            if (checkUserName(username)) {
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid username. Please ensure that your username contains an underscore and is no more than five characters in length.");
        }

        while (true) {
            password = JOptionPane.showInputDialog("Enter a password (at least 8 characters, a capital letter, a number, and a special character):");
            if (checkPasswordComplexity(password)) {
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid password. Please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
        }

        while (true) {
            cellphone = JOptionPane.showInputDialog("Enter your cell phone number (must start with +27 and be 13 digits total):");
            if (checkCellPhoneNumber(cellphone)) {
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid cell phone number. Please ensure the number is formatted correctly with international code (e.g., +27).");
        }

        // After the validation loop, store the registered details
        this.registeredUsername = username;
        this.registeredPassword = password;
        this.registeredCell = cellphone;

        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.\nUser Successfully Registered";
    }

    // Login check
    public boolean loginUser(String inputUsername, String inputPassword) {
        return inputUsername.equals(this.registeredUsername) && inputPassword.equals(this.registeredPassword);
    }

    // Login status message
    public String returnLoginStatus(boolean success, String firstName, String lastName) {
        if (success) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
