package com.mycompany.main;

import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
        Login login = new Login();
        Message messageHandler = new Message();

        // Welcome message
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");

        // Registration phase
        String regMsg = login.registerUser(); // Registration logic
        JOptionPane.showMessageDialog(null, regMsg);

        // Only continue if registration is successful
        if (regMsg.contains("successfully")) {
            String firstName = JOptionPane.showInputDialog("Enter your first name:");
            String lastName = JOptionPane.showInputDialog("Enter your last name:");

            String loginUsername = JOptionPane.showInputDialog("LOGIN\nEnter your username:");
            String loginPassword = JOptionPane.showInputDialog("Enter your password:");

            boolean isLoggedIn = login.loginUser(loginUsername, loginPassword);
            String loginMsg = login.returnLoginStatus(isLoggedIn, firstName, lastName);

            JOptionPane.showMessageDialog(null, loginMsg);

            // If login is successful, show the menu
            if (isLoggedIn) {
                boolean running = true;
                while (running) {
                    String menuOption = JOptionPane.showInputDialog(
                            "Choose an option:\n1) Send Messages\n2) Show Recently Sent Messages\n3) Quit");
                    
                    switch (menuOption) {
                        case "1":
                            try {
                                // Get number of messages to send
                                int messageCount = Integer.parseInt(JOptionPane.showInputDialog("How many messages would you like to send?"));
                                for (int i = 0; i < messageCount; i++) {
                                    messageHandler.createMessage(); // Create and handle message
                                }
                                // After sending messages, display total messages sent
                                messageHandler.printTotalMessagesSent(); // Will show "Total messages sent: 4" (or however many)
                            } catch (NumberFormatException e) {
                                JOptionPane.showMessageDialog(null, "Please enter a valid number.");
                            }
                            break;
                        case "2":
                            // Show Recently Sent Messages (coming soon message)
                            JOptionPane.showMessageDialog(null, "Coming Soon.");
                            break;
                        case "3":
                            JOptionPane.showMessageDialog(null, "Goodbye!");
                            running = false;
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Invalid option, please choose again.");
                            break;
                    }
                }
            }
        }
    }
}
