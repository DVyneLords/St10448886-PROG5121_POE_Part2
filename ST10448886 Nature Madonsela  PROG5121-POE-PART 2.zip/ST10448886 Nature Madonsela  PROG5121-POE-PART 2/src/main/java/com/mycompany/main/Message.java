package com.mycompany.main;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Random;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Message {

    private static int messageCount = 1;
    private static ArrayList<String> messageHistory = new ArrayList<>();
    private static JSONArray storedMessages = new JSONArray();

    // Generate unique message ID (10-digit)
    public String generateMessageID() {
        Random random = new Random();
        return String.format("%010d", random.nextInt(1000000000));
    }

    // Boolean: checkMessageID()
    public boolean checkMessageID(String messageID) {
        return messageID.length() == 10;
    }

    // Int: checkRecipientCell()
    public int checkRecipientCell(String recipientCell) {
        recipientCell = recipientCell.trim();
        if (recipientCell.length() == 12 && recipientCell.startsWith("+27")) {
            return 1; // Valid
        } else {
            return 0; // Invalid
        }
    }

    // String: createMessageHash()
   // String: createMessageHash()
    public String createMessageHash(String messageID, String messageContent) {
    // Extract the first 2 digits of the messageID
    String firstTwoDigits = messageID.substring(0, 2);

    // Get the first and last words from the messageContent
    String[] words = messageContent.split(" ");
    String firstWord = words.length > 0 ? words[0] : "";
    String lastWord = words.length > 1 ? words[words.length - 1] : "";

    // Combine to create the hash in the required format
    String messageHash = firstTwoDigits + ":" + (messageCount - 1) + ":" + (firstWord + lastWord).toUpperCase();
    
    return messageHash;
}

    // Store message in JSON
    public void storeMessage(String messageID, String messageHash, String recipient, String messageContent) {
        JSONObject messageDetails = new JSONObject();
        messageDetails.put("MessageID", messageID);
        messageDetails.put("MessageHash", messageHash);
        messageDetails.put("Recipient", recipient);
        messageDetails.put("Message", messageContent);

        storedMessages.add(messageDetails);

        try (FileWriter file = new FileWriter("messages.json", true)) {
            file.write(storedMessages.toJSONString());
            file.flush();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving message: " + e.getMessage());
        }
    }

    // Load stored messages
    public void loadStoredMessages() {
        try {
            FileReader reader = new FileReader("messages.json");
            JSONParser jsonParser = new JSONParser();
            Object obj = jsonParser.parse(reader);
            storedMessages = (JSONArray) obj;
        } catch (IOException | ParseException e) {
            JOptionPane.showMessageDialog(null, "Error loading messages: " + e.getMessage());
        }
    }

    // String: printMessages()
    public String printMessages() {
        StringBuilder builder = new StringBuilder();
        for (String message : messageHistory) {
            builder.append(message).append("\n\n");
        }

        String result = builder.toString();
        JOptionPane.showMessageDialog(null, result.isEmpty() ? "No messages sent." : result);
        return result;
    }

    // Int: returnTotalMessages()
    public int returnTotalMessages() {
        return messageHistory.size();
    }

    // String: SentMessage()
    public String SentMessage(String messageID, String messageHash, String recipient, String messageContent) {
        String option = JOptionPane.showInputDialog("Choose an option:\n1) Send Message\n2) Disregard Message\n3) Store Message");
        String result;

        switch (option) {
            case "1":
                messageHistory.add("MessageID: " + messageID + "\nMessage Hash: " + messageHash + "\nRecipient: " + recipient + "\nMessage: " + messageContent);
                result = "Message Sent!";
                JOptionPane.showMessageDialog(null, result + "\n\n" +
                    "MessageID: " + messageID + "\n" +
                    "Message Hash: " + messageHash + "\n" +
                    "Recipient: " + recipient + "\n" +
                    "Message: " + messageContent);
                break;
            case "2":
                result = "Message Disregarded.";
                JOptionPane.showMessageDialog(null, result);
                break;
            case "3":
                storeMessage(messageID, messageHash, recipient, messageContent);
                result = "Message Stored.";
                JOptionPane.showMessageDialog(null, result);
                break;
            default:
                result = "Invalid option.";
                JOptionPane.showMessageDialog(null, result);
                break;
        }

        return result;
    }

    // Create a message
    public void createMessage() {
        String messageID = generateMessageID();
        if (!checkMessageID(messageID)) {
            JOptionPane.showMessageDialog(null, "Message ID is invalid.");
            return;
        }

        String recipient;
        while (true) {
            recipient = JOptionPane.showInputDialog("Enter recipient cell number (must start with +27 and be 12 digits):");
            if (checkRecipientCell(recipient) == 1) {
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid recipient number. It must start with +27 and be 12 digits long.");
        }

        String messageContent;
        while (true) {
            messageContent = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
            if (messageContent.length() <= 250) {
                break;
            }
            JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters.");
        }

        String messageHash = createMessageHash(messageID, messageContent);
        String result = SentMessage(messageID, messageHash, recipient, messageContent);
        System.out.println(result);
    }

    // Display total sent messages
    public void printTotalMessagesSent() {
        JOptionPane.showMessageDialog(null, "Total number of messages sent: " + returnTotalMessages());
    }
}
